# Optragen
Matlab toolbox for parsing optimal control problems into nonlinear programming problem.
Please read the documentation under subdirectory manual.
There are a few examples that should help you get started.

