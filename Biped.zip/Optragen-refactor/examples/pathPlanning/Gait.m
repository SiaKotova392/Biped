my_biped = Biped();
biped_geom = [2.756 3.937 2.756 1.18 1.18; 2.756 3.937 2.756 1.18 1.18];
my_biped.set_geometry(biped_geom);
a_alpha = [0 0 0; 0 0 0];
my_biped.set_alpha(a_alpha);
traj = [];
for i = 1:3
    my_biped.set_stance('LEFT_FOOT')

    load('Swing_right.mat');
%     tspan = tspan .* 4;
    my_biped.animateTrajectory(tspan, traj_alpha)
    traj = [traj traj_alpha];

    load('Double1_right_left.mat');
    my_biped.animateTrajectory(tspan, traj_alpha)
    traj = [traj traj_alpha];
%     tspan = tspan .* 4;
    my_biped.set_alpha([traj_alpha(1,end), traj_alpha(2,end), traj_alpha(3,end); traj_alpha(4,end), traj_alpha(5,end), traj_alpha(6,end)]);
    [~, ~, all_frames] = my_biped.fwd_kinematics('LEFT_FOOT');
    right_foot_final = all_frames{8}.mat;
    my_biped.set_gRO(right_foot_final);

    my_biped.set_stance('RIGHT_FOOT')

    load('Swing_left.mat');
%     tspan = tspan .* 4;
    my_biped.animateTrajectory(tspan, traj_alpha)
    traj = [traj traj_alpha];

    load('Double2_left_right.mat');
%     tspan = tspan .* 4;
    my_biped.animateTrajectory(tspan, traj_alpha)
    traj = [traj traj_alpha];
    my_biped.set_alpha([traj_alpha(1,end), traj_alpha(2,end), traj_alpha(3,end); traj_alpha(4,end), traj_alpha(5,end), traj_alpha(6,end)]);
    [~, ~, all_frames] = my_biped.fwd_kinematics('RIGHT_FOOT');
    left_foot_final = all_frames{8}.mat;
    my_biped.set_gRO(left_foot_final);
end

%Final position of left foot
my_biped.get_gRO()