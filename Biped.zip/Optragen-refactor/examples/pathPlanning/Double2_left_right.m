load('Double1_right_left.mat');
traj_alpha = [traj_alpha(4:6,:); traj_alpha(1:3,:)];
my_biped = Biped();
biped_geom = [2.756 3.937 2.756 1.18 1.18; 2.756 3.937 2.756 1.18 1.18];
my_biped.set_geometry(biped_geom);
alphas = [0 0 0; 0 0 0];
my_biped.set_alpha(alphas);
my_biped.set_stance('RIGHT_FOOT')
my_biped.animateTrajectory(tspan, traj_alpha)