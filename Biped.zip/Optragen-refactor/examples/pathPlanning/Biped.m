%================================ Biped ===============================
% @class    Biped
% @brief    Model implementation for bipedal robots & supporting utilities 
%  
%  Skeleton code with stub'd out functions - to be completed as part of 
%  ECE 4560 weekly course assignments.
%
%  Note: Should utilize SE2 Matlab class
%================================ Biped ===============================
% @file     Biped.m
% @author   Alex H. Chang,   alexander.h.chang@gatech.edu
% @date     2018/09/26 [modified]
%
% @note
%   set indent to 2 spaces.
%   set tab to 4 spaces, with conversion.
%================================ Biped ===============================

classdef Biped < handle
  
  properties
    gRO = SE2();        % biped world frame
    torsoSE2 = SE2();
    alphaLeft = [];     % current joint configuration (angles) for left foot
    alphaRight = [];    % current joint configuration (angles) for right foot
    linkLeft = [];      % for the link lengths (cm) on left leg
    linkRight = [];     % for the link lengths (cm) on right leg
    stance = '';        % reference frame
    COM = [];
    motor_mass = 53.5;  % mass of motor
    num_motor = 6;      % number of motors
  end
  
  %============================ Member Functions ===========================
  methods
    
    %------------------------------ Biped ------------------------------
    % Constructor
    function obj = Biped( )
        % Initialisation of class properties
        obj.torsoSE2 = SE2([0, 0], 0);
        obj.gRO = SE2([0, 0], 0);
        obj.alphaLeft = [0 0 0];     % 0 angle on all left joints
        obj.alphaRight = [0 0 0];    % 0 angle on all right joints
        obj.stance = 'TORSO';
    end
    
    %------------------------- set_geometry ----------------------------
    % Sets geometrical properties of the bipedal model (link lenghts)
    function set_geometry( obj, a_geom )
        % Creates the class properties corresponding to geometric features of
      % the biped and assign them to the corresponding class properties
        obj.linkLeft = a_geom(1,:);     % first row of input
        obj.linkRight = a_geom(2,:);    % second row of input
        obj.COM = obj.com('TORSO');
    end
    
    %---------------------------- set_alpha ----------------------------
    % set_alpha(a_alpha)
    %
    % Sets the joint configuration for the biped.
    function set_alpha( obj, a_alpha )
        % Updates the class properties holding current joint configurations
        obj.alphaLeft = a_alpha(1,:);
        obj.alphaRight = a_alpha(2,:);
    end
    
    %-------------------------- set_stance -----------------------------
    % set_stance()
    %
    % Sets the stance of the biped
    function set_stance(obj, a_stance)
        obj.stance = a_stance;
    end
    
    %---------------------------- set_gRO ------------------------------
    % set_gRO()
    %
    % sets the gRO of the biped
    function set_gRO(obj, transform)
        result = transform*obj.gRO;
        newTransform = result.getTranslation();
        obj.gRO = SE2([newTransform(1) + .0001, 0], result.getTheta());
    end
    
    %---------------------------- get_gRO ------------------------------
    % get_gRO()
    %
    % gets the gRO of the biped
    function out = get_gRO(obj)
        out = obj.gRO;
    end
        
    %----------------------------- fwd_t_LRf -----------------------------
    % To change positions  of LEFT and RIGHT feet in realtion to the TORSO.
    % Note: previously part of fwd_kineatics function
    function [g_t_Lf, g_t_Rf] = fwd_t_LRf( obj )
      g_t_Lf = []; g_t_Rf = [];
      
      g_t_hL = SE2([0, -obj.linkLeft(1)], obj.alphaLeft(1));
      g_hL_kL = SE2([0, -obj.linkLeft(2)], obj.alphaLeft(2));
      g_hL_Lf = SE2([0, -obj.linkLeft(3)], obj.alphaLeft(3));
      g_t_Lf = g_t_hL * g_hL_kL * g_hL_Lf;
      
      g_t_hR = SE2([0, -obj.linkRight(1)], obj.alphaRight(1));
      g_hR_kR = SE2([0, -obj.linkRight(2)], obj.alphaRight(2));
      g_kR_Rf = SE2([0, -obj.linkRight(3)], obj.alphaRight(3));
      g_t_Rf = g_t_hR * g_hR_kR * g_kR_Rf;
    end
    
    %------------------------------ plotLine -------------------------------
    function plotLine(obj, f1, f2)
        if (isa(f1, 'SE2')) 
            f1 = f1.M();
        end
        if (isa(f2, 'SE2'))
            f2 = f2.M();
        end
        p1 = f1*[0;0;1];
        p2 = f1*f2(:,3);
        plot([p1(1) p2(1)], [p1(2) p2(2)], 'r-')
    end
    
    %------------------------ fwd_kinematics ------------------------
    %    Computes Biped forward kinematics based on current joint
    %    configuration and link lengths
    %
    %    Output:
    %       frame_se2_poses - cell array of SE2 objects
    function [ frame1, frame2, biped_frames ] = fwd_kinematics( obj, a_ref_frame )
        [g_t_Lf, g_t_Rf] = fwd_t_LRf(obj); % replace with function
        
        % Added missing components from above
        % Left foot -> torso, right foot -> torso
        % Left foot -> right foot, right foot-> left foot
        g_Lf_t = g_t_Lf.inv();
        g_Rf_t = g_t_Rf.inv();
        g_Lf_Rf = g_Lf_t * g_t_Rf;
        g_Rf_Lf = g_Rf_t * g_t_Lf;
        
        % LEFT
        g_t_hL = obj.torsoSE2 * SE2([0, -obj.linkLeft(1)], obj.alphaLeft(1));
        g_hL_kL = SE2([0, -obj.linkLeft(2)], obj.alphaLeft(2));
        g_t_kL = g_t_hL * g_hL_kL;
        g_kL_Lf = SE2([0, -obj.linkLeft(3)], obj.alphaLeft(3));
            
        g_Lf_footB = SE2([-obj.linkLeft(4), 0], 0);
        g_t_LfB = g_t_Lf * g_Lf_footB;
        g_Lf_footF = SE2([obj.linkLeft(5), 0], 0);
        g_t_LfF = g_t_Lf * g_Lf_footF;
        
        % RIGHT
        g_t_hR = obj.torsoSE2 * SE2([0, -obj.linkRight(1)], obj.alphaRight(1));
        g_hR_kR = SE2([0, -obj.linkRight(2)], obj.alphaRight(2));
        g_t_kR = g_t_hR * g_hR_kR;
        g_kR_Rf = SE2([0, -obj.linkRight(3)], obj.alphaRight(3));        
        
        g_Rf_footB = SE2([-obj.linkRight(4), 0], 0);
        g_t_RfB = g_t_Rf * g_Rf_footB;
        g_Rf_footF = SE2([obj.linkRight(5), 0], 0);
        g_t_RfF = g_t_Rf * g_Lf_footF;
        
        biped_frames = {};
        % ALL FRAMES
        % Add values to .mat file for storage
        switch a_ref_frame
            % Should compute and return SE(2) of RIGHT and LEFT foot frames
            case 'TORSO'
                frame1.name = 'g_t_Lf';
                frame1.mat = g_t_Lf;
                frame2.name = 'g_t_Rf';
                frame2.mat = g_t_Rf;
                
                % All intermediate frames
                % LEFT
                % Torso to left hip
                frame.name = 'g_t_hL';
                frame.mat = g_t_hL;
                biped_frames{1} = frame;
                
                % Torso to left knee
                frame.name = 'g_t_kL';
                frame.mat = g_t_kL;
                biped_frames{2} = frame;
                
                % Torso to left foot
                frame.name = 'g_t_Lf';
                frame.mat = g_t_Lf;
                biped_frames{3} = frame;
                
                % Torso to left foot back
                frame.name = 'g_t_LfB';
                frame.mat = g_t_LfB;
                biped_frames{4} = frame;
                
                % Torso to left foot front
                frame.name = 'g_t_LfF';
                frame.mat = g_t_LfF;
                biped_frames{5} = frame;
                
                % RIGHT
                % Torso to right hip
                frame.name = 'g_t_hR';
                frame.mat = g_t_hR;
                biped_frames{6} = frame;
                
                % Torso to right knee
                frame.name = 'g_t_kR';
                frame.mat = g_t_kR;
                biped_frames{7} = frame;
                
                % Torso to right foot
                frame.name = 'g_t_Rf';
                frame.mat = g_t_Rf;
                biped_frames{8} = frame;
                
                % Torso to right foot back
                frame.name = 'g_t_RfB';
                frame.mat = g_t_RfB;
                biped_frames{9} = frame;
                
                % Torso to right foot front
                frame.name = 'g_t_RfF';
                frame.mat = g_t_RfF;
                biped_frames{10} = frame;
                
            % Should compute and return SE(2) of TORSO and RIGHT foot frames
            case 'LEFT_FOOT'
                frame1.name = 'g_Lf_t';
                frame1.mat = g_Lf_t;
                frame2.name = 'g_Lf_Rf';
                frame2.mat = g_Lf_Rf;
                
                % All intermediate frames
                % LEFT
                % Left foot to back of foot
                frame.name = 'g_Lf_footB';
                frame.mat = g_Lf_footB;
                biped_frames{1} = frame;
                
                % Left foot to front of foot
                frame.name = 'g_Lf_footF';
                frame.mat = g_Lf_footF;
                biped_frames{2} = frame;
                
                % Left foot to left knee
                frame.name = 'g_Lf_kL';
                frame.mat = g_kL_Lf.inv();
                biped_frames{3} = frame;
                
                % Left foot to left hip
                frame.name = 'g_Lf_hL';
                frame.mat = g_kL_Lf.inv() * g_hL_kL.inv();
                biped_frames{4} = frame;
                
                % Left foot to torso
                frame.name = 'g_Lf_t';
                frame.mat = g_Lf_t;
                biped_frames{5} = frame;
                
                % RIGHT
                % Left foot to right hip
                frame.name = 'g_Lf_hR';
                frame.mat = g_Lf_t * g_t_hR;
                biped_frames{6} = frame;
                
                % Left foot to right knee
                frame.name = 'g_Lf_kR';
                frame.mat = g_Lf_t * g_t_kR;
                biped_frames{7} = frame;
                
                % Left foot to right foot
                frame.name = 'g_Lf_Rf';
                frame.mat = g_Lf_t * g_t_Rf;
                biped_frames{8} = frame;
                
                % Left foot to right foot back
                frame.name = 'g_Lf_RfB';
                frame.mat = g_Lf_t * g_t_RfB;
                biped_frames{9} = frame;
                
                % Left foot to right foot front
                frame.name = 'g_Lf_RfF';
                frame.mat = g_Lf_t * g_t_RfF;
                biped_frames{10} = frame;
                
            % Should compute and return SE(2) of TORSO and LEFT foot frames
            case 'RIGHT_FOOT'
                frame1.name = 'g_Rf_t';
                frame1.mat = g_Rf_t;
                frame2.name = 'g_Rf_Lf';
                frame2.mat = g_Rf_Lf;
                
                % RIGHT
                % Right foot to back of foot
                frame.name = 'g_RF_footB';
                frame.mat = g_Rf_footB;
                biped_frames{1} = frame;
                
                % Right foot to front of foot
                frame.name = 'g_Rf_footF';
                frame.mat = g_Rf_footF;
                biped_frames{2} = frame;
                
                % Right foot to right knee
                frame.name = 'g_Rf_kR';
                frame.mat = g_kR_Rf.inv();
                biped_frames{3} = frame;
                
                % Right foot to right hip
                frame.name = 'g_Rf_hR';
                frame.mat = g_kR_Rf.inv() * g_hR_kR.inv();
                biped_frames{4} = frame;
                
                % Right foot to torso
                frame.name = 'g_Rf_t';
                frame.mat = g_Rf_t;
                biped_frames{5} = frame;
                
                % LEFT
                % Right foot to left hip
                frame.name = 'g_Rf_hL';
                frame.mat = g_Rf_t * g_t_hL;
                biped_frames{6} = frame;
                
                % Right foot to left knee
                frame.name = 'g_Rf_kL';
                frame.mat = g_Rf_t * g_t_kL;
                biped_frames{7} = frame;
                
                % Right foot to left foot
                frame.name = 'g_Rf_Lf';
                frame.mat = g_Rf_t * g_t_Lf;
                biped_frames{8} = frame;
                
                % Right foot to left foot back
                frame.name = 'g_Rf_LfB';
                frame.mat = g_Rf_t * g_t_LfB;
                biped_frames{9} = frame;
                
                % Right foot to left foot front
                frame.name = 'g_Rf_LfF';
                frame.mat = g_Rf_t * g_t_LfF;
                biped_frames{10} = frame;
            otherwise
        end
    end
    
    %----------------------------- plotTf ------------------------------
    % plotTF()
    %
    % Plot the torso frame, both foot frames and all links, consistent
    % with the biped's current joint configuration and link lengths.
    function plotTF( obj )
        % Sets current stance to the object stance
        stance_now = obj.stance;
        [~, ~, all_frames] = obj.fwd_kinematics(stance_now);
        origin_frame = obj.gRO;
        
        switch stance_now
            case 'TORSO'
                origin_frame.plot('TORSO');
                
                % Torso to left hip
                g_t_hL = origin_frame * all_frames{1,1}.mat;
                g_t_hL.plot('t_hL');
                obj.plotLine(origin_frame, origin_frame.inv() * g_t_hL);
                
                % Torso to left knee
                g_t_kL = origin_frame * all_frames{1,2}.mat;
                g_t_kL.plot('t_kL');
                obj.plotLine(g_t_hL, (g_t_hL.inv() * g_t_kL));
                
                % Torso to left leg
                g_t_Lf = origin_frame * all_frames{1,3}.mat;
                g_t_Lf.plot('t_Lf');
                obj.plotLine(g_t_kL, (g_t_kL.inv() * g_t_Lf));
                
                % Torso to left foot (front and back)
                g_t_LfB = origin_frame * all_frames{1,4}.mat;
                g_t_LfF = origin_frame * all_frames{1,5}.mat;
                obj.plotLine(g_t_Lf, g_t_Lf.inv() * g_t_LfB);
                obj.plotLine(g_t_Lf, g_t_Lf.inv() * g_t_LfF);
                
                % Torso to right hip
                g_Lf_hR = origin_frame * all_frames{1,6}.mat;
                g_Lf_hR.plot('t_hR');
                obj.plotLine(origin_frame, origin_frame.inv() * g_Lf_hR);
                
                % Torso to right knee
                g_t_kR = origin_frame * all_frames{1,7}.mat;
                g_t_kR.plot('t_kR');
                obj.plotLine(g_Lf_hR, (g_Lf_hR.inv() * g_t_kR));
                
                % Torso to right leg
                g_t_Rf = origin_frame * all_frames{1,8}.mat;
                g_t_Rf.plot('t_Rf');
                obj.plotLine(g_t_kR, (g_t_kR.inv() * g_t_Rf));
                
                % Torso to right foot (front and back)
                g_t_RfB = origin_frame * all_frames{1,9}.mat;
                g_t_RfF = origin_frame * all_frames{1,10}.mat;
                obj.plotLine(g_t_Rf, g_t_Rf.inv() * g_t_RfB);
                obj.plotLine(g_t_Rf, g_t_Rf.inv() * g_t_RfF);
                
                % Lab3
                obj.COM = obj.com('TORSO')
            case 'LEFT_FOOT'
                origin_frame.plot('LEFT_FOOT')
                
                % Left foot wrt to left foot front and back
                g_Rf_LfB = origin_frame * all_frames{1,1}.mat;
                g_Lf_LfF = origin_frame * all_frames{1,2}.mat;
                obj.plotLine(origin_frame, origin_frame.inv() * g_Rf_LfB);
                obj.plotLine(origin_frame, origin_frame.inv() * g_Lf_LfF);
                
                % Left leg to left knee
                g_Lf_kL = origin_frame * all_frames{1,3}.mat;
                g_Lf_kL.plot('Lf_kL');
                obj.plotLine(origin_frame, origin_frame.inv() * g_Lf_kL);
                
                % Left leg to left hip
                g_Lf_hL = origin_frame * all_frames{1,4}.mat;
                g_Lf_hL.plot('Lf_hL');
                obj.plotLine(g_Lf_kL, g_Lf_kL.inv() * g_Lf_hL);
                
                % Left leg to torso
                g_Lf_t = origin_frame * all_frames{1,5}.mat;
                g_Lf_t.plot('Lf_t');
                obj.plotLine(g_Lf_hL, g_Lf_hL.inv() * g_Lf_t);
               
                % Left leg to right hip
                g_Lf_hR = origin_frame * all_frames{1,6}.mat;
                g_Lf_hR.plot('Lf_hR');
                obj.plotLine(g_Lf_t, g_Lf_t.inv() * g_Lf_hR);
                
                % Left leg to right knee
                g_Lf_kR = origin_frame * all_frames{1,7}.mat;
                g_Lf_kR.plot('Lf_kR');
                obj.plotLine(g_Lf_hR, g_Lf_hR.inv() * g_Lf_kR);
                
                % Left leg to right leg
                g_Lf_Rf = origin_frame * all_frames{1,8}.mat;
                g_Lf_Rf.plot('Lf_Rf');
                obj.plotLine(g_Lf_kR, g_Lf_kR.inv() * g_Lf_Rf);
                
                % Left leg to right foot front and back
                g_Lf_RfB = origin_frame * all_frames{1,9}.mat;
                g_Lf_RfF = origin_frame * all_frames{1,10}.mat;
                obj.plotLine(g_Lf_Rf, g_Lf_Rf.inv() * g_Lf_RfB);
                obj.plotLine(g_Lf_Rf, g_Lf_Rf.inv() * g_Lf_RfF);
                
                % ADDED
                obj.COM = obj.com('LEFT_FOOT');  
            case 'RIGHT_FOOT'
                origin_frame.plot('RIGHT_FOOT')
                
                % Right foot wrt to right foot front and back
                g_Rf_RfB = origin_frame * all_frames{1,1}.mat;
                g_Rf_RfF = origin_frame * all_frames{1,2}.mat;
                obj.plotLine(origin_frame, origin_frame.inv() * g_Rf_RfB);
                obj.plotLine(origin_frame, origin_frame.inv() * g_Rf_RfF);
                
                % Right leg to right knee
                g_Rf_kR = origin_frame * all_frames{1,3}.mat;
                g_Rf_kR.plot('Rf_kR');
                obj.plotLine(origin_frame, origin_frame.inv() * g_Rf_kR);
                
                % Right leg to right hip
                g_Rf_hR = origin_frame * all_frames{1,4}.mat;
                g_Rf_hR.plot('Rf_hR');
                obj.plotLine(g_Rf_kR, g_Rf_kR.inv() * g_Rf_hR);
                
                % Right leg to torso
                g_Rf_t = origin_frame * all_frames{1,5}.mat;
                g_Rf_t.plot('Rf_t');
                obj.plotLine(g_Rf_hR, g_Rf_hR.inv() * g_Rf_t);
                
                % Right leg to left hip
                g_Rf_hL = origin_frame * all_frames{1,6}.mat;
                g_Rf_hL.plot('Rf_hL');
                obj.plotLine(g_Rf_t, g_Rf_t.inv() * g_Rf_hL);
                
                % Right lef to left knee
                g_Rf_kL = origin_frame * all_frames{1,7}.mat;
                g_Rf_kL.plot('Rr_kL');
                obj.plotLine(g_Rf_hL, g_Rf_hL.inv() * g_Rf_kL);
                
                % Right lef to left leg
                g_Rf_Lf = origin_frame * all_frames{1,8}.mat;
                g_Rf_Lf.plot('Rf_Lf');
                obj.plotLine(g_Rf_kL, g_Rf_kL.inv() * g_Rf_Lf);
                
                % Right leg to left foot front and back
                g_Rf_LfB = origin_frame * all_frames{1,9}.mat;
                g_Rf_LfF = origin_frame * all_frames{1,10}.mat;
                obj.plotLine(g_Rf_Lf, g_Rf_Lf.inv() * g_Rf_LfB);
                obj.plotLine(g_Rf_Lf, g_Rf_Lf.inv() * g_Rf_LfF);
                
                % ADDED
                obj.COM = obj.com('RIGHT_FOOT');
            otherwise
        end
        
        hold on
        translation = obj.gRO.getTranslation();
        plot(obj.COM(1) + translation(1), obj.COM(2) + translation(2), 'g*');
        % Plotting CoM: https://www.mathworks.com/matlabcentral/answers/98665-how-do-i-plot-a-circle-with-a-given-radius-and-center
        % Use viscircles? https://www.mathworks.com/help/images/ref/viscircles.html
        % Green circled X?
        % Note: Make sure to have Image Processing Toolbox to use!!
        viscircles([obj.COM(1) + translation(1), obj.COM(2) + translation(2)], 0.2, 'EdgeColor', 'g');
    end
      
    %------------------------- animateTrajectory --------------------------
    % For each time instant of a_time, compute the biped forward kinematics 
    % for the joint values at that instant and update a stick figure plot of 
    % the biped (including plotted biped frames).
    function animateTrajectory( obj, a_time, a_joint_traj )
        curr_angles = [a_joint_traj(1:3,1)'; a_joint_traj(4:6,1)'];
        obj.set_alpha(curr_angles);
        obj.plotTF();
        tTime = a_time(1, 1);     % It's tea time boys
        
        % Tic Toc for measuring elapsed time
        % Reference: https://www.mathworks.com/help/matlab/ref/tic.html
        % NOTE: Have to move through a_joint_traj in sync with a_time
        tocTime = 0;
        for i = 2:length(a_time)
            tic;
            curr_angles = [a_joint_traj(1:3,i)'; a_joint_traj(4:6,i)'];
            obj.set_alpha(curr_angles);
            % Resets plot, clears plot, retains plot for redrawing
            hold off; clf; hold on;
            obj.plotTF();
            tocTime = toc;
            timeDiff = a_time(1, i) - tTime - tocTime;
            tTime = a_time(1, i);
            pause(timeDiff);
        end
    end
    
    %-------------------------------- com ---------------------------------
    % Computes the centre of mass position of biped wrt torso, left_foot,
    % or right_foot reference frame (a_ref_frame). Will change based on the
    % robot's current joint configuration.
     %-------------------------------- com ---------------------------------
    % Computes the centre of mass position of biped wrt torso, left_foot,
    % or right_foot reference frame (a_ref_frame). Will change based on the
    % robot's current joint configuration.
    function [pos_com] = com(obj, a_ref_frame)
        [~, ~, all_frames] = obj.fwd_kinematics(a_ref_frame);
        % Initialises centre as origin
        centre = [0;0;0];
        % X direction for limbs 'leg' for left and right sides
        % -Y direction for limbs 'hip' and 'knee' for left and right sides
        % Z direction never changes, so keep [x; y; 1];
        
        switch a_ref_frame
            case 'TORSO'
                % Torso to left hip
                centre = centre + obj.motor_mass .* (all_frames{1}.mat.M() * [0;-0.53;1]);
                % Torso to left knee
                centre = centre + obj.motor_mass .* (all_frames{2}.mat.M() * [0;-0.53;1]);
                % Torso to left foot
                centre = centre + obj.motor_mass .* (all_frames{3}.mat.M() * [0.53;0;1]);
                % Torso to right hip
                centre = centre + obj.motor_mass .* (all_frames{6}.mat.M() * [0;-0.53;1]);
                % Torso to right knee
                centre = centre + obj.motor_mass .* (all_frames{7}.mat.M() * [0;-0.53;1]);
                % Torso to right foot
                centre = centre + obj.motor_mass .* (all_frames{8}.mat.M() * [0.53;0;1]);
            case 'LEFT_FOOT'
                centre = centre + obj.motor_mass .* (all_frames{3}.mat.M() * [0;-0.53;1]);
                centre = centre + obj.motor_mass .* (all_frames{4}.mat.M() * [0;-0.53;1]);
                centre = centre + obj.motor_mass .* (all_frames{5}.mat.M() * [0.53;0;1]);
                centre = centre + obj.motor_mass .* (all_frames{6}.mat.M() * [0;-0.53;1]);
                centre = centre + obj.motor_mass .* (all_frames{7}.mat.M() * [0;-0.53;1]);
                centre = centre + obj.motor_mass .* (all_frames{8}.mat.M() * [0.53;0;1]);
            case 'RIGHT_FOOT'
                centre = centre + obj.motor_mass .* (all_frames{3}.mat.M() * [0;-0.53;1]);
                centre = centre + obj.motor_mass .* (all_frames{4}.mat.M() * [0;-0.53;1]);
                centre = centre + obj.motor_mass .* (all_frames{5}.mat.M() * [0.53;0;1]);
                centre = centre + obj.motor_mass .* (all_frames{6}.mat.M() * [0;-0.53;1]);
                centre = centre + obj.motor_mass .* (all_frames{7}.mat.M() * [0;-0.53;1]);
                centre = centre + obj.motor_mass .* (all_frames{8}.mat.M() * [0.53;0;1]);
        end
        centre = centre ./ (obj.num_motor * obj.motor_mass);
        pos_com = [centre(1); centre(2)];
    end
    
    function out = rot_mat(alpha)
        out = [cos(alpha) -sin(alpha); sin(alpha) cos(alpha)];
    end
    
    %----------------------------- jacobian -------------------------------
    % J is a 3xN matrix that maps joint velocities, alpha_dot
    % (vector of length, N) to velocity twist coordinates, [xdot, ydot,
    % thetadot] representing velocity of end-effector frame (a_ee_frame)
    % wrt reference frame (a_ref_frame).
    % Return: 3x3 matrix that maps alpha_dot (vector of length 3) to
    % corresponding twist of the selected foot frame.
    % PARAMS: 
    %   - J = 3xN matrix that maps alpha_dot to [xdot, ydot, thetadot]
    %   - alpha_dot = vector of length N
    %   - a_alpha = 3 element vector for joint positions between
    % end-effector and reference frames.
    %   - a_ref_frame = reference frame
    %   - a_ee_frame = end-effector frame (choice of LEFT or RIGHT)
    function [J] = jacobian( obj, a_alpha, a_ref_frame, a_ee_frame )

        J = [];
        switch a_ref_frame
            case 'TORSO'
                l1 = 0; l2 = 0; l3 = 0;
                
                if (strcmp(a_ee_frame, 'LEFT_FOOT'))
                    l1 = obj.linkLeft(1);
                    l2 = obj.linkLeft(2);
                    l3 = obj.linkLeft(3);
                end
                
                if (strcmp(a_ee_frame, 'RIGHT_FOOT'))
                    l1 = obj.linkRight(1);
                    l2 = obj.linkRight(2);
                    l3 = obj.linkRight(3);
                end
                
                syms t1 t2 t3 x(t1, t2, t3) y(t1, t2, t3) theta(t1, t2, t3)
                
                g_t_l1(t1, t2, t3) = [cos(t1), -sin(t1), 0; sin(t1), cos(t1), -l1; 0, 0, 1];
                g_l1_l2(t1, t2, t3) = [cos(t2), -sin(t2), 0; sin(t2), cos(t2), -l2; 0, 0, 1];
                g_l2_l3(t1, t2, t3) = [cos(t3), -sin(t3), 0; sin(t3), cos(t3), -l3; 0, 0, 1];
                
                config(t1, t2, t3) = simplify(g_t_l1 * g_l1_l2 * g_l2_l3);
                % Removing this breaks stuff.
                % DO NOT REMOVE
                final_config_sym = config(t1, t2, t3);
                
                x(t1, t2, t3) = final_config_sym(1, 3);
                y(t1, t2, t3) = final_config_sym(2, 3);
                theta(t1, t2, t3) = t1 + t2 + t3;
                
                qe = [x; y; theta];
                J_sym = jacobian(qe,[t1, t2, t3]);
                J = double(J_sym(a_alpha(1), a_alpha(2), a_alpha(3)));
        end
           
    end
    
    %----------------------------- rr_inv_kin -----------------------------
    % PARAMS:
    %   - a_ref_frame = reference frame
    %   - a_ee_frame = end-effector frame
    %   - a_traj_ws = 3xT foot frame trajectory wrt a_ref_frame
    %        - T = # of waypoints comprising your trajectory and x,y,theta
    %   - a_time = 1xT holding timestamps in a_traj_ws
    %   - Output: traj_alpha = 3xT with
    %        = [ahip; aknee; aankle] all are 1xT vectors
    function [traj_alpha] = rr_inv_kin( obj, a_traj_ws, a_time, a_ref_frame, a_ee_frame )
        [g_t_Lf, g_t_Rf] = fwd_t_LRf(obj);
        g_t_Lf_mat = g_t_Lf.M();
        traj_alpha = [];
        
        switch a_ref_frame
            case 'TORSO'
                if (a_ee_frame == 'LEFT_FOOT')
                    t = 0;
                    % dummy variables
                    xi = g_t_Lf_mat(1,3);
                    yi = g_t_Lf_mat(2,3);
                    thetai = acos(g_t_Lf_mat(1,1));
                    % assign alphas
                    alpha1 = obj.alphaLeft(1);
                    alpha2 = obj.alphaLeft(2);
                    alpha3 = obj.alphaLeft(3);
                    a_a = [alpha1; alpha2; alpha3];
                    for i = 1:length(a_time)
                        % "time maganement"
                        dt = a_time(i) - t;
                        t = a_time(i);
                        % compute differentials
                        x_dot = a_traj_ws(1,i) - xi;
                        y_dot = a_traj_ws(2,i) - yi;
                        theta_dot = a_traj_ws(3,i) - thetai;
                        % update dummy variables
                        xi = a_traj_ws(1,i);
                        yi = a_traj_ws(2,i);
                        thetai = a_traj_ws(3,i);
                        twist = [x_dot; y_dot; theta_dot] ./ dt;
                        % compute jacobian
                        J = jacobian(obj, a_a, a_ref_frame, a_ee_frame);
                        % handle alpha differential
                        % use pinv from HW9
                        a_dot = pinv(J) * twist;
                        a_a = a_a + a_dot .* dt;
                        % update trajectory
                        % take out of the loop for efficiency?
                        % --> breaks, other ideas?
                        traj_alpha = [traj_alpha a_a];
                    end
                end
        end
                    
    end
  end     % methods
end