% =======================================================================
%   OCP2NLP
%   Copyright (c) 2005 by
%   Raktim Bhattacharya, (raktim@aero.tamu.edu)
%   Department of Aerospace Engineering
%   Texas A&M University.
%   All right reserved.
% =======================================================================
clear all;
global nlp;

addpath('../../');
addpath('../../src');
SNOPTPATH = '/home/ECE4560_B2/Desktop/4560/snopt';
addpath([ SNOPTPATH ]);
addpath([ SNOPTPATH '/matlab/matlab/' ]);
addpath([ SNOPTPATH '/matlab/mex/' ]);

% Typesetting for figure text
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultTextInterpreter','latex');

ninterv = 2;
hl = 1.0;

% l_1 = 0.5; l_2 = 0.5;   % link lengths
l_1 = 2.756; l_2 = 3.937; l_3 = 2.756;

% initial/final end-effector poses
x0 = -4;
y0 = 0;
theta0 = 0;
xf = 4;
yf = 0;
thetaf = 0;
CoM_back = 0;
CoM_front = 2.36; % CoM = 3 --> better animation, bad mat files !
CoM_height = l_1 + l_2 + l_3;

eps = 0.0001;

% Generate symbolic representation of end-effector pose
syms a1 a2 a3 a4 a5 a6    % a1 = joint 1 angle; a2 = joint 2 angle
                          % a4-a6 right leg joing angles
                          
g_ee = [cos(a1+a2+a3-a4-a5-a6), sin(a1+a2+a3-a4-a5-a6), (29*sin(a2+a3))/8 - (29*sin(a1+a2+a3-a4-a5))/8 - ...
    (29*sin(a1+a2+a3-a4))/8 + (29*sin(a3))/8; ...
    -sin(a1+a2+a3-a4-a5-a6), cos(a1+a2+a3-a4-a5-a6), (29*cos(a2+a3))/8 - (29*cos(a1+a2+a3-a4-a5))/8 - ...
    (29*cos(a1+a2+a3-a4))/8 + (29*cos(a3))/8; ...
    0,0,1];

pos_com_x = (53*cos(a1+a2+a3-a4-a5-a6))/600 - (277*sin(a1+a2+a3-a4-a5))/400 + (1173*sin(a2+a3))/400 - ...
        (389*sin(a1+a2+a3-a4))/300 + (1061*sin(a3))/300 + (42809^(1/2)*cos(a1+a2+a3 - atan(200/53)))/600;
pos_com_y = (1173*cos(a2+a3))/400 - ...
        (277*cos(a1+a2+a3-a4-a5))/400 -(53*sin(a1+a2+a3-a4-a5-a6))/600 - (389*cos(a1+a2+a3-a4))/300 + ...
        (1061*cos(a3))/300 + (42809^(1/2)*cos(a1+a2+a3 + atan(53/200)))/600;

g_ee_x_str = char(vpa(g_ee(1, 3), 9));      % end-effector x- spatial position
g_ee_y_str = char(vpa(g_ee(2, 3), 9));      % end-effector y- spatial position

%All joints
% Left
g_lf_p2L = [cos(a3)/(cos(a3)^2+sin(a3)^2), sin(a3)/(cos(a3)^2+sin(a3)^2), (29*sin(a3))/(8*(cos(a3)^2 + sin(a3)^2));
    -sin(a3)/(cos(a3)^2 + sin(a3)^2), cos(a3)/(cos(a3)^2 + sin(a3)^2), (29*cos(a3))/(8*(cos(a3)^2 + sin(a3)^2));
     0, 0, 1];
g_lf_p2L_x_str = char(vpa(g_lf_p2L(1,3), 9));
g_lf_p2L_y_str = char(vpa(g_lf_p2L(2,3), 9));

% Right
g_lf_p2R = [cos(a1+a2+a3-a4-a5), sin(a1+a2+a3-a4-a5), (29*sin(a2+a3))/8 - (29*sin(a1+a2+a3-a4))/8 + (29*sin(a3))/8;
    -sin(a1+a2+a3-a4-a5), cos(a1+a2+a3-a4-a5), (29*cos(a2+a3))/8 - (29*cos(a1+a2+a3-a4))/8 + (29*cos(a3))/8;
    0, 0, 1];
g_lf_p2R_x_str = char(vpa(g_lf_p2R(1,3), 9));
g_lf_p2R_y_str = char(vpa(g_lf_p2R(2,3), 9));

pos_com_x_str = char(pos_com_x);
pos_com_y_str = char(pos_com_y);
g_ee_theta_str = char(a1+a2+a3+a4+a5+a6);

g_torso_left_leg_str = char(a1+a2+a3);
g_torso_right_leg_str = char(a4+a5+a6);

g_ee_a1_str = char(a1);
g_ee_a2_str = char(a2);
g_ee_a3_str = char(a3);
g_ee_a4_str = char(a4);
g_ee_a5_str = char(a5);
g_ee_a6_str = char(a6);

% Create trajectory variablesbase
% ===========================
a1 = traj('a1', ninterv,2,3); % Arguments are ninterv, smoothness, order
a2 = traj('a2', ninterv,2,3);
a3 = traj('a3', ninterv,2,3);
a4 = traj('a4', ninterv,2,3);
a5 = traj('a5', ninterv,2,3);
a6 = traj('a6', ninterv,2,3);

% Create derivatives of trajectory variables
% ==========================================
a1d = deriv(a1, 'a1');
a2d = deriv(a2, 'a2');
a3d = deriv(a3, 'a3');
a4d = deriv(a4, 'a4');
a5d = deriv(a5, 'a5');
a6d = deriv(a6, 'a6');

ParamList = [];
xVars = {'a1'; 'a2'; 'a3'; 'a4'; 'a5'; 'a6'; ...
        'a1d'; 'a2d'; 'a3d'; 'a4d'; 'a5d'; 'a6d'};

% Define constraints
% ==================
%% ADDED
Constr = constraint(x0,g_ee_x_str,x0,'initial', xVars) + ... % x(0)
    constraint(y0,g_ee_y_str,y0,'initial', xVars) + ... % y(0)
    constraint(theta0,g_ee_theta_str,theta0,'initial', xVars) + ... % theta(0)
    constraint(xf,g_ee_x_str,xf,'final', xVars) + ...     % Final position, time is normalised
    constraint(yf,g_ee_y_str,yf,'final', xVars) + ...
    constraint(thetaf,g_ee_theta_str,thetaf,'final', xVars) + ... 
    constraint(x0-.5,g_ee_x_str,xf+.5,'trajectory', xVars) + ... % Rl x and y constaints      
    constraint(-pi/3,g_ee_a1_str,(3*pi)/4,'trajectory',xVars) + ... % DO NOT REMOVE
    constraint(-pi,g_ee_a4_str, pi/2,'trajectory',xVars) + ...
    constraint(-pi/2,g_ee_a2_str,0,'trajectory',xVars) + ... %Left knee cannot bend outward
    constraint(-3*pi/4,g_ee_a5_str,0,'trajectory',xVars) + ... %Right knee cannot bend inward
    constraint(0,g_ee_a3_str,pi/4,'trajectory',xVars) + ... % DO NOT REMOVE
    constraint(0,g_ee_a6_str,pi/4,'trajectory',xVars) + ...
    constraint(0,g_torso_right_leg_str,0,'initial',xVars) + ... %T_Rl needs to start at 0 angle
    constraint(0,g_torso_right_leg_str,0,'final',xVars) + ... ; %T_Rl needs to end at 0 angle
    constraint(CoM_back,pos_com_x_str,CoM_front,'trajectory',xVars) %+ ... % COM x constraint
    constraint(0,pos_com_y_str,CoM_height,'trajectory',xVars) ; % COM y constraint

% Define Cost Function
% ====================
Cost = cost('a1d^2+a1d+a2d^2+a4d^2+a4d+a5d^2','trajectory'); % Minimise energy

% Collocation Points, using Gaussian Quadrature formula
% =====================================================

breaks = linspace(0,hl,ninterv+1);
gauss = [-1 1]*sqrt(1/3)/2;
temp = ((breaks(2:ninterv+1)+breaks(1:ninterv))/2);
temp = temp(ones(1,length(gauss)),:) + gauss'*diff(breaks);
colpnts = temp(:).';

HL = [0 colpnts hl];
HL = linspace(0,hl,20);

% Path where the problem related files will be stored
% ===================================================
pathName = './';  % Save it all in the current directory.

% Name of the problem, will be used to identify files
% ===================================================
probName = 'planar2r';

% List of trajectories used in the problem
% ========================================
TrajList = traj.trajList(a1,a1d,a2,a2d,a3,a3d,a4,a4d,a5,a5d,a6,a6d);

nlp = ocp2nlp(TrajList, Cost,Constr, HL, ParamList,pathName,probName);
snset('Minimize');

xlow = -Inf*ones(nlp.nIC,1);
xupp = Inf*ones(nlp.nIC,1);

Time = linspace(0,5,40);
a1_val = linspace(-pi,pi,40);
a2_val = linspace(-pi,pi,40);
a3_val = linspace(-pi,pi,40);
a4_val = linspace(-pi,pi,40);
a5_val = linspace(-pi,pi,40);
a6_val = linspace(-pi,pi,40);

a1_sp = createGuess(a1,Time,a1_val);
a2_sp = createGuess(a2,Time,a2_val);
a3_sp = createGuess(a3,Time,a3_val);
a4_sp = createGuess(a4,Time,a4_val);
a5_sp = createGuess(a5,Time,a5_val);
a6_sp = createGuess(a6,Time,a6_val);
init = [a1_sp.coefs a2_sp.coefs a3_sp.coefs ...
    a4_sp.coefs a5_sp.coefs a6_sp.coefs]';

%init = [a1_sp.coefs a2_sp.coefs a3_sp.coefs]';% + 0.001*rand(nlp.nIC,1);
%init = zeros(nlp.nIC,1);

ghSnopt = snoptFunction(nlp);
tic;
[x,F,inform] = snopt(init, xlow, xupp, [], [], ...
                     [0;nlp.LinCon.lb;nlp.nlb], [Inf;nlp.LinCon.ub;nlp.nub],...
                     [], [], ghSnopt);
toc;
F(1)

sp = getTrajSplines(nlp,x);
a1SP = sp{1};
a2SP = sp{2};
a3SP = sp{3};
a4SP = sp{4};
a5SP = sp{5};
a6SP = sp{6};

refinedTimeGrid = linspace(min(HL),max(HL),40);

A1 = fnval(a1SP,refinedTimeGrid);
A1d = fnval(fnder(a1SP),refinedTimeGrid);

A2 = fnval(a2SP,refinedTimeGrid);
A2d = fnval(fnder(a2SP),refinedTimeGrid);

A3 = fnval(a3SP,refinedTimeGrid);
A3d = fnval(fnder(a3SP),refinedTimeGrid);

A4 = fnval(a4SP,refinedTimeGrid);
A4d = fnval(fnder(a4SP),refinedTimeGrid);

A5 = fnval(a5SP,refinedTimeGrid);
A5d = fnval(fnder(a5SP),refinedTimeGrid);

A6 = fnval(a6SP,refinedTimeGrid);
A6d = fnval(fnder(a6SP),refinedTimeGrid);

% Planar 2-R Arm joint trajectory
% figure(1);
% plot3(A1,A2,A3,'b');
% xlabel('Joint 1 (rad)'); ylabel('Joint 2 (rad)'); zlabel('Joint 3 (rad)');
% title('Joint Trajectory');
% figure(2);
% plot3(A4,A5,A6,'b');
% xlabel('Joint 4 (rad)'); ylabel('Joint 5 (rad)'); zlabel('Joint 6 (rad)');
% title('Joint Trajectory');

tspan = Time;
% traj_alpha = [A1; A2; A3; zeros(3,length(tspan))];
traj_alpha = [A1; A2; A3; A4; A5; A6];

% -------------------------------Lab 8-------------------------------------

% Instantiate instance/object of the Biped() class
my_biped = Biped();

% Set Biped link lengths (cm)
% [LEFT; RIGHT] = [l0 l1 l2 l3 l4; l0 l1 l2 l3 l4]
biped_geom = [2.756 3.937 2.756 1.18 1.18; 2.756 3.937 2.756 1.18 1.18];
my_biped.set_geometry( biped_geom );

% Set Biped joint configuration
% biped_alphas = [pi/3 -pi/5 pi/7; 0 0 0]; % UPD: angles for this week's purposes
biped_alphas = [0 0 0; 0 0 0];
my_biped.set_alpha(biped_alphas);
my_biped.set_stance('LEFT_FOOT');

% % Plots of each relevant joint angle vs. time (i.e., 3 plots)
% % LEFT LEG
% figure
% hold on
% subplot(2,2,1)
% plot(tspan, traj_alpha(1,:));
% title('Hip vs Time for Left Leg');
% xlabel('t');
% ylabel('alpha hip');
% subplot(2,2,2)
% plot(tspan, traj_alpha(2,:));
% title('Knee vs Time for Right Leg');
% xlabel('t');
% ylabel('alpha knee');
% subplot(2,2,[3,4]);
% plot(tspan, traj_alpha(3,:));
% title('Ankle vs Time for Right Leg');
% xlabel('t');
% ylabel('alpha ankle');
% hold off
% 
% % Plots of each relevant joint angle vs. time (i.e., 3 plots)
% % RIGHT LEG
% figure
% hold on
% subplot(2,2,1)
% plot(tspan, traj_alpha(4,:));
% title('Hip vs Time for Right Leg');
% xlabel('t');
% ylabel('alpha hip');
% subplot(2,2,2)
% plot(tspan, traj_alpha(5,:));
% title('Knee vs Time for Right Leg');
% xlabel('t');
% ylabel('alpha knee');
% subplot(2,2,[3,4]);
% plot(tspan, traj_alpha(6,:));
% title('Ankle vs Time for Right Leg');
% xlabel('t');
% ylabel('alpha ankle');
% hold off

% Produce an animation
a_time_anim = tspan(1:2:end);
traj_alpha_anim = traj_alpha(:,2:2:end);
my_biped.animateTrajectory(a_time_anim, traj_alpha_anim) 